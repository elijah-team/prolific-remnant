package tripleo.elijah.lang.i;

/*
 * Created on 5/19/2019 at 23:36
 */
public interface IInvariantStatement {
}
