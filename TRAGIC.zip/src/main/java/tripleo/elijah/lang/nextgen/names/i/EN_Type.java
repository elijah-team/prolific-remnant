package tripleo.elijah.lang.nextgen.names.i;

public interface EN_Type {
}
