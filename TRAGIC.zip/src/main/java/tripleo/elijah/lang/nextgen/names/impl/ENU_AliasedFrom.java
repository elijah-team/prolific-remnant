package tripleo.elijah.lang.nextgen.names.impl;

import tripleo.elijah.lang.AliasStatement;
import tripleo.elijah.lang.nextgen.names.i.EN_Understanding;

public record ENU_AliasedFrom(AliasStatement aliasStatement) implements EN_Understanding {
}
