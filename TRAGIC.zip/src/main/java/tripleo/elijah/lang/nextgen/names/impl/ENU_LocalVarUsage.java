package tripleo.elijah.lang.nextgen.names.impl;

import tripleo.elijah.lang.nextgen.names.i.EN_Understanding;
import tripleo.elijah.lang.nextgen.names.i.EN_Usage;

public class ENU_LocalVarUsage implements EN_Understanding, EN_Usage {
}
