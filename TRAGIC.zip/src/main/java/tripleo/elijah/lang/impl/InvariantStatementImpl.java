package tripleo.elijah.lang.impl;

import tripleo.elijah.lang.i.IInvariantStatement;

/*
 * Created on 5/19/2019 at 23:36
 */
public class InvariantStatementImpl implements IInvariantStatement {
}
