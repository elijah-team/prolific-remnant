package tripleo.elijah.nextgen.expansion;

public interface SX_Node {
	String text();

	String fullText();
}
