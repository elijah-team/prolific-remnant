package tripleo.elijah.nextgen.query;

public enum Mode {
	SUCCESS, FAILURE, NOTHING
}
