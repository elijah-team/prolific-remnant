package tripleo.elijah.nextgen.outputtree;

@FunctionalInterface
public interface EOT_FileNameProvider {
	String getFilename();
}
