package tripleo.elijah.nextgen.reactive;

public interface Reactivable {
	void respondTo(ReactiveDimension aDimension);
}