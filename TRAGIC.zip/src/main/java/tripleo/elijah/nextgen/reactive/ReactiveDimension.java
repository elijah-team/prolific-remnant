package tripleo.elijah.nextgen.reactive;

public interface ReactiveDimension {
}
