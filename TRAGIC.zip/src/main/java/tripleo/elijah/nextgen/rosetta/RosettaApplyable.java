package tripleo.elijah.nextgen.rosetta;

public interface RosettaApplyable {
	void apply();
}
