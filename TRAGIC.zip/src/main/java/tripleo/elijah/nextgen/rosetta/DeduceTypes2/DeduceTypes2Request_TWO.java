package tripleo.elijah.nextgen.rosetta.DeduceTypes2;

public class DeduceTypes2Request_TWO {
}
