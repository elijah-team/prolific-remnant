package tripleo.elijah.nextgen.inputtree;

public interface EIT_Input {
	EIT_InputType getType();
}
