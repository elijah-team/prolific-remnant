package tripleo.elijah.nextgen.inputtree;

public enum EIT_InputType {
	ELIJAH_SOURCE, EZ_FILE
}
