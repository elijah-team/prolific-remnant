package tripleo.elijah.nextgen.model;

public interface SM_Name {
	String getText();
}
