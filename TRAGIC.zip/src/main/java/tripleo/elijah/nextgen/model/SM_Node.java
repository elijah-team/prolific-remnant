package tripleo.elijah.nextgen.model;

public interface SM_Node {
}
