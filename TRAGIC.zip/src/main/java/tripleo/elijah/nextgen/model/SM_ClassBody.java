package tripleo.elijah.nextgen.model;

import java.util.*;

public interface SM_ClassBody extends SM_Node {
	List<SM_Node> children();
}
