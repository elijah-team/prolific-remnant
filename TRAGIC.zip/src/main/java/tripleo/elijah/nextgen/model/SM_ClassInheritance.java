package tripleo.elijah.nextgen.model;

import java.util.*;

public interface SM_ClassInheritance {
	List<SM_Name> names();
}
