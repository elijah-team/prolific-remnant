package tripleo.elijah.nextgen.model;

public enum SM_ClassSubtype {
	NORMAL, INTERFACE, STRUCT, SIGNATURE, ABSTRACT
}
