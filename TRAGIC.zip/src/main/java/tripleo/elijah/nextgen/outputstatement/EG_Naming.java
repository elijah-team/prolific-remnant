package tripleo.elijah.nextgen.outputstatement;

public class EG_Naming {
	final String s;
	final String s1;

	public EG_Naming(final String aS, final String aS1) {
		s  = aS;
		s1 = aS1;
	}

	public EG_Naming(final String aS) {
		s  = aS;
		s1 = null;
	}
}
