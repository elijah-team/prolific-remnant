/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tripleo.elijah.nextgen.outputstatement;

/**
 * @author Tripleo Nova
 */
public interface EG_Statement {
	String getText();

	EX_Explanation getExplanation();
}
