package tripleo.elijah.nextgen.outputstatement;

public class EG_EnclosedStatement {
}
