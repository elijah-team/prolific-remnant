package tripleo.elijah.nextgen.outputstatement;

// README a mini EG_Statement
public interface IReasonedString {
	String text();

	String reason();
}
