package tripleo.elijah.nextgen.small;

public interface ES_Item {
}
