package tripleo.elijah.stages.deduce.fluffy.impl;

import tripleo.elijah.stages.deduce.fluffy.i.*;

public class FluffyVarTargetImpl implements FluffyVarTarget {
	@Override
	public T getT() {
		return null;
	}
}
