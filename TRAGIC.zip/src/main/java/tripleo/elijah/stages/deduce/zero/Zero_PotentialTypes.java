package tripleo.elijah.stages.deduce.zero;

public class Zero_PotentialTypes {
}
