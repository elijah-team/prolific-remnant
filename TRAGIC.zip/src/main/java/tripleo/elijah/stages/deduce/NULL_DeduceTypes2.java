package tripleo.elijah.stages.deduce;

public class NULL_DeduceTypes2 {
}
