package tripleo.elijah.stages.deduce.fluffy.impl;

import org.jetbrains.annotations.*;
import tripleo.elijah.diagnostic.*;
import tripleo.elijah.nextgen.composable.*;
import tripleo.elijah.stages.deduce.fluffy.i.*;

public class FluffyVarImpl implements FluffyVar {
	@Override
	public String name() {
		return null;
	}

	@Override
	public @Nullable Locatable nameLocatable() {
		return null;
	}

	@Override
	public IComposable nameComposable() {
		return null;
	}

	@Override
	public FluffyVarTarget target() {
		return null;
	}
}
