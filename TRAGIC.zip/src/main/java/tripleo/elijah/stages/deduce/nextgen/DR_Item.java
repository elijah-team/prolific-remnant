package tripleo.elijah.stages.deduce.nextgen;

public interface DR_Item {
}
