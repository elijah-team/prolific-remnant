package tripleo.elijah.stages.deduce.fluffy.i;

import tripleo.elijah.ci.*;

public interface FluffyLsp {

	LibraryStatementPart getLsp();
}
