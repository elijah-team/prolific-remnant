package tripleo.elijah.stages.deduce.zero;

public interface IZero {
}
