package tripleo.elijah.stages.deduce.nextgen;

import tripleo.elijah.lang.OS_Element;

public interface DT_ResolveObserver {
	void onElement(OS_Element best);
}
