package tripleo.elijah.stages.gen_c;

import tripleo.elijah.stages.gen_generic.GenerateResultEnv;

interface WhyNotGarish_Item {
	boolean hasFileGen();

	void provideFileGen(GenerateResultEnv fg);
}
