package tripleo.elijah.util;

public interface IFixedList<T> {
	int size();

	T get(int at);
}
