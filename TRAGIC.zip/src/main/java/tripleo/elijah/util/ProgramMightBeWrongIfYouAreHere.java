package tripleo.elijah.util;

public class ProgramMightBeWrongIfYouAreHere extends RuntimeException {
}
