package tripleo.elijah.util;

public class SimplePrintLoggerToRemoveSoon {
	public static void println_err(final String aS) {
//		System.err.println(aS);
	}

	public static void println_out(final String aS) {
//		System.out.println(aS);
	}

  public static void println2(final String aS) {
//		System.out.println(""+aS);
	}

	public static void println_err2(final String aS) {
//		System.err.println(""+aS);
	}

	public static void println_out_2(final String aS) {
//		System.out.println(""+aS);
  }
}
