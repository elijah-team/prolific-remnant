package tripleo.elijah.ci;

public interface CiListExpression {
	void setContents(CiExpressionList aEl);
}
