package tripleo.elijah.nextgen.output;

import org.jetbrains.annotations.NotNull;
import tripleo.elijah.lang.i.OS_Module;
import tripleo.elijah.nextgen.inputtree.EIT_ModuleInput;
import tripleo.elijah.nextgen.outputstatement.EG_Statement;
import tripleo.elijah.nextgen.outputstatement.EX_Explanation;
import tripleo.elijah.stages.gen_c.C2C_Result;
import tripleo.elijah.stages.gen_generic.GenerateResult.TY;

public class NG_OutputFunctionStatement implements NG_OutputStatement {
   private final EG_Statement x;
   private final TY y;
   @NotNull
   private final NG_OutDep moduleDependency;
   @NotNull
   private final C2C_Result __c2c;

   public NG_OutputFunctionStatement(@NotNull C2C_Result ac2c) {
      if (ac2c == null) {
         $$$reportNull$$$0(0);
      }

      super();
      this.__c2c = ac2c;
      this.x = this.__c2c.getStatement();
      this.y = this.__c2c.ty();
      this.moduleDependency = new NG_OutDep(ac2c.getDefinedModule());
   }

   @NotNull
   public EX_Explanation getExplanation() {
      EX_Explanation var10000 = EX_Explanation.withMessage("NG_OutputFunctionStatement");
      if (var10000 == null) {
         $$$reportNull$$$0(1);
      }

      return var10000;
   }

   public String getText() {
      return this.x.getText();
   }

   public TY getTy() {
      return this.y;
   }

   @NotNull
   public EIT_ModuleInput getModuleInput() {
      OS_Module m = this.moduleDependency().getModule();
      EIT_ModuleInput moduleInput = new EIT_ModuleInput(m, m.getCompilation());
      if (moduleInput == null) {
         $$$reportNull$$$0(2);
      }

      return moduleInput;
   }

   public NG_OutDep moduleDependency() {
      return this.moduleDependency;
   }

   // $FF: synthetic method
   private static void $$$reportNull$$$0(int var0) {
      String var10000;
      switch(var0) {
      case 0:
      default:
         var10000 = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
         break;
      case 1:
      case 2:
         var10000 = "@NotNull method %s.%s must not return null";
      }

      byte var10001;
      switch(var0) {
      case 0:
      default:
         var10001 = 3;
         break;
      case 1:
      case 2:
         var10001 = 2;
      }

      Object[] var2 = new Object[var10001];
      switch(var0) {
      case 0:
      default:
         var2[0] = "ac2c";
         break;
      case 1:
      case 2:
         var2[0] = "tripleo/elijah/nextgen/output/NG_OutputFunctionStatement";
      }

      switch(var0) {
      case 0:
      default:
         var2[1] = "tripleo/elijah/nextgen/output/NG_OutputFunctionStatement";
         break;
      case 1:
         var2[1] = "getExplanation";
         break;
      case 2:
         var2[1] = "getModuleInput";
      }

      switch(var0) {
      case 0:
      default:
         var2[2] = "<init>";
      case 1:
      case 2:
         var10000 = String.format(var10000, var2);
         Object var1;
         String var4;
         switch(var0) {
         case 0:
         default:
            IllegalArgumentException var3 = new IllegalArgumentException;
            var4 = var10000;
            var1 = var3;
            var3.<init>(var4);
            break;
         case 1:
         case 2:
            IllegalStateException var10002 = new IllegalStateException;
            var4 = var10000;
            var1 = var10002;
            var10002.<init>(var4);
         }

         throw var1;
      }
   }
}
