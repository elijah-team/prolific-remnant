package tripleo.elijah.nextgen.output;

import java.util.List;
import org.jetbrains.annotations.NotNull;
import tripleo.elijah.nextgen.outputtree.EOT_FileNameProvider;
import tripleo.elijah.stages.gen_generic.GenerateResult.TY;
import tripleo.elijah.stages.generate.OutputStrategyC;

public interface NG_OutputItem {
   @NotNull
   List getOutputs();

   EOT_FileNameProvider outName(OutputStrategyC var1, TY var2);
}
