package tripleo.elijah.nextgen.output;

import org.jetbrains.annotations.NotNull;
import tripleo.elijah.lang.i.OS_Module;
import tripleo.elijah.nextgen.inputtree.EIT_ModuleInput;
import tripleo.elijah.nextgen.outputstatement.EX_Explanation;
import tripleo.elijah.stages.gen_generic.GenerateResult.TY;
import tripleo.util.buffer.Buffer;

public class NG_OutputNamespaceStatement implements NG_OutputStatement {
   private final Buffer buf;
   private final TY ty;
   @NotNull
   private final NG_OutDep moduleDependency;

   public NG_OutputNamespaceStatement(Buffer aBuf, TY aTY, @NotNull OS_Module aM) {
      if (aM == null) {
         $$$reportNull$$$0(0);
      }

      super();
      this.buf = aBuf;
      this.ty = aTY;
      this.moduleDependency = new NG_OutDep(aM);
   }

   @NotNull
   public EX_Explanation getExplanation() {
      EX_Explanation var10000 = EX_Explanation.withMessage("NG_OutputNamespaceStatement");
      if (var10000 == null) {
         $$$reportNull$$$0(1);
      }

      return var10000;
   }

   public String getText() {
      return this.buf.getText();
   }

   public TY getTy() {
      return this.ty;
   }

   @NotNull
   public EIT_ModuleInput getModuleInput() {
      OS_Module m = this.moduleDependency().getModule();
      EIT_ModuleInput moduleInput = new EIT_ModuleInput(m, m.getCompilation());
      if (moduleInput == null) {
         $$$reportNull$$$0(2);
      }

      return moduleInput;
   }

   @NotNull
   public NG_OutDep moduleDependency() {
      NG_OutDep var10000 = this.moduleDependency;
      if (var10000 == null) {
         $$$reportNull$$$0(3);
      }

      return var10000;
   }

   // $FF: synthetic method
   private static void $$$reportNull$$$0(int var0) {
      String var10000;
      switch(var0) {
      case 0:
      default:
         var10000 = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
         break;
      case 1:
      case 2:
      case 3:
         var10000 = "@NotNull method %s.%s must not return null";
      }

      byte var10001;
      switch(var0) {
      case 0:
      default:
         var10001 = 3;
         break;
      case 1:
      case 2:
      case 3:
         var10001 = 2;
      }

      Object[] var2 = new Object[var10001];
      switch(var0) {
      case 0:
      default:
         var2[0] = "aM";
         break;
      case 1:
      case 2:
      case 3:
         var2[0] = "tripleo/elijah/nextgen/output/NG_OutputNamespaceStatement";
      }

      switch(var0) {
      case 0:
      default:
         var2[1] = "tripleo/elijah/nextgen/output/NG_OutputNamespaceStatement";
         break;
      case 1:
         var2[1] = "getExplanation";
         break;
      case 2:
         var2[1] = "getModuleInput";
         break;
      case 3:
         var2[1] = "moduleDependency";
      }

      switch(var0) {
      case 0:
      default:
         var2[2] = "<init>";
      case 1:
      case 2:
      case 3:
         var10000 = String.format(var10000, var2);
         Object var1;
         String var4;
         switch(var0) {
         case 0:
         default:
            IllegalArgumentException var3 = new IllegalArgumentException;
            var4 = var10000;
            var1 = var3;
            var3.<init>(var4);
            break;
         case 1:
         case 2:
         case 3:
            IllegalStateException var10002 = new IllegalStateException;
            var4 = var10000;
            var1 = var10002;
            var10002.<init>(var4);
         }

         throw var1;
      }
   }
}
