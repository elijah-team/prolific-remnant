package kotlin.coroutines.intrinsics;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt", "kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt"}
)
public final class IntrinsicsKt extends IntrinsicsKt__IntrinsicsKt {
   private IntrinsicsKt() {
   }
}
