package kotlin.jvm.internal;

public class InlineMarker {
   public static void mark(int i) {
   }

   public static void mark(String name) {
   }

   public static void beforeInlineCall() {
   }

   public static void afterInlineCall() {
   }

   public static void finallyStart(int finallyDepth) {
   }

   public static void finallyEnd(int finallyDepth) {
   }
}
