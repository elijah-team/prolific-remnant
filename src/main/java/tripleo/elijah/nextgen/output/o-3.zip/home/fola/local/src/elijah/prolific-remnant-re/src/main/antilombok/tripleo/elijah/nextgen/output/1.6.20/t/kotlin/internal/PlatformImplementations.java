package kotlin.internal;

import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.MatchResult;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.FallbackThreadLocalRandom;
import kotlin.random.Random;
import kotlin.text.MatchGroup;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\b\u0010\u0018\u00002\u00020\u0001:\u0001\u0012B\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0016J\b\u0010\b\u001a\u00020\tH\u0016J\u001a\u0010\n\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u0016\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u00112\u0006\u0010\u0007\u001a\u00020\u0006H\u0016¨\u0006\u0013"},
   d2 = {"Lkotlin/internal/PlatformImplementations;", "", "()V", "addSuppressed", "", "cause", "", "exception", "defaultPlatformRandom", "Lkotlin/random/Random;", "getMatchResultNamedGroup", "Lkotlin/text/MatchGroup;", "matchResult", "Ljava/util/regex/MatchResult;", "name", "", "getSuppressed", "", "ReflectThrowable", "kotlin-stdlib"}
)
public class PlatformImplementations {
   public void addSuppressed(@NotNull Throwable cause, @NotNull Throwable exception) {
      Intrinsics.checkNotNullParameter(cause, "cause");
      Intrinsics.checkNotNullParameter(exception, "exception");
      Method var10000 = PlatformImplementations.ReflectThrowable.addSuppressed;
      if (var10000 != null) {
         Object[] var3 = new Object[]{exception};
         var10000.invoke(cause, var3);
      }

   }

   @NotNull
   public List getSuppressed(@NotNull Throwable exception) {
      Intrinsics.checkNotNullParameter(exception, "exception");
      Method var10000 = PlatformImplementations.ReflectThrowable.getSuppressed;
      List var6;
      if (var10000 != null) {
         Object var5 = var10000.invoke(exception);
         if (var5 != null) {
            Object var2 = var5;
            int var4 = false;
            var6 = ArraysKt.asList((Throwable[])var2);
            if (var6 != null) {
               return var6;
            }
         }
      }

      var6 = CollectionsKt.emptyList();
      return var6;
   }

   @Nullable
   public MatchGroup getMatchResultNamedGroup(@NotNull MatchResult matchResult, @NotNull String name) {
      Intrinsics.checkNotNullParameter(matchResult, "matchResult");
      Intrinsics.checkNotNullParameter(name, "name");
      throw new UnsupportedOperationException("Retrieving groups by name is not supported on this platform.");
   }

   @NotNull
   public Random defaultPlatformRandom() {
      return (Random)(new FallbackThreadLocalRandom());
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lkotlin/internal/PlatformImplementations$ReflectThrowable;", "", "()V", "addSuppressed", "Ljava/lang/reflect/Method;", "getSuppressed", "kotlin-stdlib"}
   )
   private static final class ReflectThrowable {
      @NotNull
      public static final PlatformImplementations.ReflectThrowable INSTANCE = new PlatformImplementations.ReflectThrowable();
      @JvmField
      @Nullable
      public static final Method addSuppressed;
      @JvmField
      @Nullable
      public static final Method getSuppressed;

      static {
         Class throwableClass = Throwable.class;
         Method[] throwableMethods = throwableClass.getMethods();
         Intrinsics.checkNotNullExpressionValue(throwableMethods, "throwableMethods");
         Method[] var2 = throwableMethods;
         int var3 = 0;
         int var4 = throwableMethods.length;

         Method var5;
         boolean var7;
         Method var9;
         while(true) {
            if (var3 >= var4) {
               var9 = null;
               break;
            }

            boolean var8;
            label36: {
               var5 = var2[var3];
               var7 = false;
               if (Intrinsics.areEqual((Object)var5.getName(), (Object)"addSuppressed")) {
                  Class[] var10000 = var5.getParameterTypes();
                  Intrinsics.checkNotNullExpressionValue(var10000, "it.parameterTypes");
                  if (Intrinsics.areEqual((Object)ArraysKt.singleOrNull((Object[])var10000), (Object)throwableClass)) {
                     var8 = true;
                     break label36;
                  }
               }

               var8 = false;
            }

            if (var8) {
               var9 = var5;
               break;
            }

            ++var3;
         }

         addSuppressed = var9;
         var2 = throwableMethods;
         var3 = 0;
         var4 = throwableMethods.length;

         while(true) {
            if (var3 >= var4) {
               var9 = null;
               break;
            }

            var5 = var2[var3];
            var7 = false;
            if (Intrinsics.areEqual((Object)var5.getName(), (Object)"getSuppressed")) {
               var9 = var5;
               break;
            }

            ++var3;
         }

         getSuppressed = var9;
      }
   }
}
