package kotlin.ranges;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/ranges/URangesKt___URangesKt"}
)
public final class URangesKt extends URangesKt___URangesKt {
   private URangesKt() {
   }
}
