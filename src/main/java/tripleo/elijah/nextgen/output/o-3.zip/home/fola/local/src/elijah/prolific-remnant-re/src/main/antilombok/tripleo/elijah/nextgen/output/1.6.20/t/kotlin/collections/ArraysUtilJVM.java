package kotlin.collections;

import java.util.Arrays;
import java.util.List;

class ArraysUtilJVM {
   static List asList(Object[] array) {
      return Arrays.asList(array);
   }
}
