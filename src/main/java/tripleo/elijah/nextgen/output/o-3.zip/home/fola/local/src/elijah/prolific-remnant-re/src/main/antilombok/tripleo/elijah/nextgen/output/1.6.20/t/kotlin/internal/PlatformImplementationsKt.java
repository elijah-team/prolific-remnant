package kotlin.internal;

import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.SinceKotlin;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0004\u001a \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u0005H\u0001\u001a\"\u0010\b\u001a\u0002H\t\"\n\b\u0000\u0010\t\u0018\u0001*\u00020\n2\u0006\u0010\u000b\u001a\u00020\nH\u0083\b¢\u0006\u0002\u0010\f\u001a\b\u0010\r\u001a\u00020\u0005H\u0002\"\u0010\u0010\u0000\u001a\u00020\u00018\u0000X\u0081\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"},
   d2 = {"IMPLEMENTATIONS", "Lkotlin/internal/PlatformImplementations;", "apiVersionIsAtLeast", "", "major", "", "minor", "patch", "castToBaseType", "T", "", "instance", "(Ljava/lang/Object;)Ljava/lang/Object;", "getJavaVersion", "kotlin-stdlib"}
)
public final class PlatformImplementationsKt {
   @JvmField
   @NotNull
   public static final PlatformImplementations IMPLEMENTATIONS;

   // $FF: synthetic method
   @InlineOnly
   private static final Object castToBaseType(Object instance) {
      try {
         Intrinsics.reifiedOperationMarker(1, "T");
         return (Object)instance;
      } catch (ClassCastException var4) {
         ClassLoader instanceCL = instance.getClass().getClassLoader();
         Intrinsics.reifiedOperationMarker(4, "T");
         ClassLoader baseTypeCL = ((Class)Object.class).getClassLoader();
         if (!Intrinsics.areEqual((Object)instanceCL, (Object)baseTypeCL)) {
            throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + instanceCL + ", base type classloader: " + baseTypeCL, (Throwable)var4);
         } else {
            throw var4;
         }
      }
   }

   private static final int getJavaVersion() {
      int var0 = 65542;
      String var10000 = System.getProperty("java.specification.version");
      if (var10000 == null) {
         return var0;
      } else {
         String version = var10000;
         int firstDot = StringsKt.indexOf$default((CharSequence)version, '.', 0, false, 6, (Object)null);
         int secondDot;
         if (firstDot < 0) {
            try {
               secondDot = Integer.parseInt(version) * 65536;
            } catch (NumberFormatException var8) {
               secondDot = var0;
            }

            return secondDot;
         } else {
            secondDot = StringsKt.indexOf$default((CharSequence)version, '.', firstDot + 1, false, 4, (Object)null);
            if (secondDot < 0) {
               secondDot = version.length();
            }

            byte var6 = 0;
            var10000 = version.substring(var6, firstDot);
            Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String…ing(startIndex, endIndex)");
            String firstPart = var10000;
            int var7 = firstDot + 1;
            var10000 = version.substring(var7, secondDot);
            Intrinsics.checkNotNullExpressionValue(var10000, "this as java.lang.String…ing(startIndex, endIndex)");
            String secondPart = var10000;

            int var10;
            try {
               var10 = Integer.parseInt(firstPart) * 65536 + Integer.parseInt(secondPart);
            } catch (NumberFormatException var9) {
               var10 = var0;
            }

            return var10;
         }
      }
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.2"
   )
   public static final boolean apiVersionIsAtLeast(int major, int minor, int patch) {
      return KotlinVersion.CURRENT.isAtLeast(major, minor, patch);
   }

   static {
      PlatformImplementations var10000;
      label107: {
         int var0 = false;
         int version = getJavaVersion();
         Object var2;
         ClassLoader var4;
         ClassLoader var5;
         Object var14;
         if (version >= 65544 || version < 65536) {
            try {
               var14 = Class.forName("kotlin.internal.jdk8.JDK8PlatformImplementations").newInstance();
               Intrinsics.checkNotNullExpressionValue(var14, "forName(\"kotlin.internal…entations\").newInstance()");
               var2 = var14;

               try {
                  if (var2 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                  }

                  var10000 = (PlatformImplementations)var2;
                  break label107;
               } catch (ClassCastException var11) {
                  var4 = var2.getClass().getClassLoader();
                  var5 = PlatformImplementations.class.getClassLoader();
                  if (!Intrinsics.areEqual((Object)var4, (Object)var5)) {
                     throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var4 + ", base type classloader: " + var5, (Throwable)var11);
                  }

                  throw var11;
               }
            } catch (ClassNotFoundException var13) {
               try {
                  var14 = Class.forName("kotlin.internal.JRE8PlatformImplementations").newInstance();
                  Intrinsics.checkNotNullExpressionValue(var14, "forName(\"kotlin.internal…entations\").newInstance()");
                  var2 = var14;

                  try {
                     if (var2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                     }

                     var10000 = (PlatformImplementations)var2;
                     break label107;
                  } catch (ClassCastException var10) {
                     var4 = var2.getClass().getClassLoader();
                     var5 = PlatformImplementations.class.getClassLoader();
                     if (!Intrinsics.areEqual((Object)var4, (Object)var5)) {
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var4 + ", base type classloader: " + var5, (Throwable)var10);
                     }

                     throw var10;
                  }
               } catch (ClassNotFoundException var12) {
               }
            }
         }

         if (version >= 65543 || version < 65536) {
            try {
               var14 = Class.forName("kotlin.internal.jdk7.JDK7PlatformImplementations").newInstance();
               Intrinsics.checkNotNullExpressionValue(var14, "forName(\"kotlin.internal…entations\").newInstance()");
               var2 = var14;

               try {
                  if (var2 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                  }

                  var10000 = (PlatformImplementations)var2;
                  break label107;
               } catch (ClassCastException var7) {
                  var4 = var2.getClass().getClassLoader();
                  var5 = PlatformImplementations.class.getClassLoader();
                  if (!Intrinsics.areEqual((Object)var4, (Object)var5)) {
                     throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var4 + ", base type classloader: " + var5, (Throwable)var7);
                  }

                  throw var7;
               }
            } catch (ClassNotFoundException var9) {
               try {
                  var14 = Class.forName("kotlin.internal.JRE7PlatformImplementations").newInstance();
                  Intrinsics.checkNotNullExpressionValue(var14, "forName(\"kotlin.internal…entations\").newInstance()");
                  var2 = var14;

                  try {
                     if (var2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                     }

                     var10000 = (PlatformImplementations)var2;
                     break label107;
                  } catch (ClassCastException var6) {
                     var4 = var2.getClass().getClassLoader();
                     var5 = PlatformImplementations.class.getClassLoader();
                     if (!Intrinsics.areEqual((Object)var4, (Object)var5)) {
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var4 + ", base type classloader: " + var5, (Throwable)var6);
                     }

                     throw var6;
                  }
               } catch (ClassNotFoundException var8) {
               }
            }
         }

         var10000 = new PlatformImplementations();
      }

      IMPLEMENTATIONS = var10000;
   }
}
