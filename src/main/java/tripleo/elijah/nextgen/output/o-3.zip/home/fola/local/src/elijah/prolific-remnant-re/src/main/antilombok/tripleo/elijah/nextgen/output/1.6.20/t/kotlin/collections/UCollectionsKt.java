package kotlin.collections;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/collections/UCollectionsKt___UCollectionsKt"}
)
public final class UCollectionsKt extends UCollectionsKt___UCollectionsKt {
   private UCollectionsKt() {
   }
}
