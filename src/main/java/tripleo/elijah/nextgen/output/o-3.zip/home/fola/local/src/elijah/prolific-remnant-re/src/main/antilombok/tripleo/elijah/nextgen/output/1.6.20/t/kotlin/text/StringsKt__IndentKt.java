package kotlin.text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u000b\u001a!\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0002H\u0002¢\u0006\u0002\b\u0004\u001a\u0011\u0010\u0005\u001a\u00020\u0006*\u00020\u0002H\u0002¢\u0006\u0002\b\u0007\u001a\u0014\u0010\b\u001a\u00020\u0002*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u001aJ\u0010\t\u001a\u00020\u0002*\b\u0012\u0004\u0012\u00020\u00020\n2\u0006\u0010\u000b\u001a\u00020\u00062\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u00012\u0014\u0010\r\u001a\u0010\u0012\u0004\u0012\u00020\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001H\u0082\b¢\u0006\u0002\b\u000e\u001a\u0014\u0010\u000f\u001a\u00020\u0002*\u00020\u00022\b\b\u0002\u0010\u0010\u001a\u00020\u0002\u001a\u001e\u0010\u0011\u001a\u00020\u0002*\u00020\u00022\b\b\u0002\u0010\u0010\u001a\u00020\u00022\b\b\u0002\u0010\u0012\u001a\u00020\u0002\u001a\n\u0010\u0013\u001a\u00020\u0002*\u00020\u0002\u001a\u0014\u0010\u0014\u001a\u00020\u0002*\u00020\u00022\b\b\u0002\u0010\u0012\u001a\u00020\u0002¨\u0006\u0015"},
   d2 = {"getIndentFunction", "Lkotlin/Function1;", "", "indent", "getIndentFunction$StringsKt__IndentKt", "indentWidth", "", "indentWidth$StringsKt__IndentKt", "prependIndent", "reindent", "", "resultSizeEstimate", "indentAddFunction", "indentCutFunction", "reindent$StringsKt__IndentKt", "replaceIndent", "newIndent", "replaceIndentByMargin", "marginPrefix", "trimIndent", "trimMargin", "kotlin-stdlib"},
   xs = "kotlin/text/StringsKt"
)
class StringsKt__IndentKt extends StringsKt__AppendableKt {
   @NotNull
   public static final String trimMargin(@NotNull String $this$trimMargin, @NotNull String marginPrefix) {
      Intrinsics.checkNotNullParameter($this$trimMargin, "<this>");
      Intrinsics.checkNotNullParameter(marginPrefix, "marginPrefix");
      return StringsKt.replaceIndentByMargin($this$trimMargin, "", marginPrefix);
   }

   // $FF: synthetic method
   public static String trimMargin$default(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "|";
      }

      return StringsKt.trimMargin(var0, var1);
   }

   @NotNull
   public static final String replaceIndentByMargin(@NotNull String $this$replaceIndentByMargin, @NotNull String newIndent, @NotNull String marginPrefix) {
      Intrinsics.checkNotNullParameter($this$replaceIndentByMargin, "<this>");
      Intrinsics.checkNotNullParameter(newIndent, "newIndent");
      Intrinsics.checkNotNullParameter(marginPrefix, "marginPrefix");
      boolean var3 = !StringsKt.isBlank((CharSequence)marginPrefix);
      if (!var3) {
         int var4 = false;
         String var40 = "marginPrefix must be non-blank string.";
         throw new IllegalArgumentException(var40.toString());
      } else {
         List lines = StringsKt.lines((CharSequence)$this$replaceIndentByMargin);
         int resultSizeEstimate$iv = $this$replaceIndentByMargin.length() + newIndent.length() * lines.size();
         Function1 indentAddFunction$iv = getIndentFunction$StringsKt__IndentKt(newIndent);
         int $i$f$reindent = false;
         int lastIndex$iv = CollectionsKt.getLastIndex(lines);
         Iterable $this$mapIndexedNotNull$iv$iv = (Iterable)lines;
         int $i$f$mapIndexedNotNull = false;
         Collection destination$iv$iv$iv = (Collection)(new ArrayList());
         int $i$f$mapIndexedNotNullTo = false;
         int $i$f$forEachIndexed = false;
         int index$iv$iv$iv$iv = 0;
         Iterator var17 = $this$mapIndexedNotNull$iv$iv.iterator();

         String var41;
         while(var17.hasNext()) {
            Object item$iv$iv$iv$iv = var17.next();
            int var19 = index$iv$iv$iv$iv++;
            if (var19 < 0) {
               CollectionsKt.throwIndexOverflow();
            }

            int var22 = false;
            String value$iv = (String)item$iv$iv$iv$iv;
            int var25 = false;
            if ((var19 == 0 || var19 == lastIndex$iv) && StringsKt.isBlank((CharSequence)value$iv)) {
               var41 = null;
            } else {
               label84: {
                  int var27 = false;
                  CharSequence $this$indexOfFirst$iv = (CharSequence)value$iv;
                  int $i$f$indexOfFirst = false;
                  int index$iv = 0;
                  int var31 = $this$indexOfFirst$iv.length();

                  int var10000;
                  while(true) {
                     if (index$iv >= var31) {
                        var10000 = -1;
                        break;
                     }

                     char it = $this$indexOfFirst$iv.charAt(index$iv);
                     int var33 = false;
                     if (!CharsKt.isWhitespace(it)) {
                        var10000 = index$iv;
                        break;
                     }

                     ++index$iv;
                  }

                  int firstNonWhitespaceIndex = var10000;
                  if (firstNonWhitespaceIndex == -1) {
                     var41 = null;
                  } else if (StringsKt.startsWith$default(value$iv, marginPrefix, firstNonWhitespaceIndex, false, 4, (Object)null)) {
                     int var42 = firstNonWhitespaceIndex + marginPrefix.length();
                     var41 = value$iv.substring(var42);
                     Intrinsics.checkNotNullExpressionValue(var41, "this as java.lang.String).substring(startIndex)");
                  } else {
                     var41 = null;
                  }

                  if (var41 != null) {
                     String var35 = var41;
                     var41 = (String)indentAddFunction$iv.invoke(var35);
                     if (var41 != null) {
                        break label84;
                     }
                  }

                  var41 = value$iv;
               }
            }

            if (var41 != null) {
               String var36 = var41;
               int var38 = false;
               destination$iv$iv$iv.add(var36);
            }
         }

         var41 = ((StringBuilder)CollectionsKt.joinTo$default((Iterable)((List)destination$iv$iv$iv), (Appendable)(new StringBuilder(resultSizeEstimate$iv)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 124, (Object)null)).toString();
         Intrinsics.checkNotNullExpressionValue(var41, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
         return var41;
      }
   }

   // $FF: synthetic method
   public static String replaceIndentByMargin$default(String var0, String var1, String var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = "";
      }

      if ((var3 & 2) != 0) {
         var2 = "|";
      }

      return StringsKt.replaceIndentByMargin(var0, var1, var2);
   }

   @NotNull
   public static final String trimIndent(@NotNull String $this$trimIndent) {
      Intrinsics.checkNotNullParameter($this$trimIndent, "<this>");
      return StringsKt.replaceIndent($this$trimIndent, "");
   }

   @NotNull
   public static final String replaceIndent(@NotNull String $this$replaceIndent, @NotNull String newIndent) {
      Intrinsics.checkNotNullParameter($this$replaceIndent, "<this>");
      Intrinsics.checkNotNullParameter(newIndent, "newIndent");
      List lines = StringsKt.lines((CharSequence)$this$replaceIndent);
      Iterable $this$map$iv = (Iterable)lines;
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$mapTo = false;
      Iterator var10 = $this$map$iv.iterator();

      Object item$iv$iv;
      String p0;
      boolean $i$f$mapIndexedNotNullTo;
      while(var10.hasNext()) {
         item$iv$iv = var10.next();
         p0 = (String)item$iv$iv;
         $i$f$mapIndexedNotNullTo = false;
         if (!StringsKt.isBlank((CharSequence)p0)) {
            destination$iv$iv.add(item$iv$iv);
         }
      }

      $this$map$iv = (Iterable)((List)destination$iv$iv);
      $i$f$map = false;
      destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      $i$f$mapTo = false;
      var10 = $this$map$iv.iterator();

      while(var10.hasNext()) {
         item$iv$iv = var10.next();
         p0 = (String)item$iv$iv;
         $i$f$mapIndexedNotNullTo = false;
         destination$iv$iv.add(indentWidth$StringsKt__IndentKt(p0));
      }

      Integer var10000 = (Integer)CollectionsKt.minOrNull((Iterable)((List)destination$iv$iv));
      int minCommonIndent = var10000 != null ? var10000 : 0;
      int resultSizeEstimate$iv = $this$replaceIndent.length() + newIndent.length() * lines.size();
      Function1 indentAddFunction$iv = getIndentFunction$StringsKt__IndentKt(newIndent);
      int $i$f$reindent = false;
      int lastIndex$iv = CollectionsKt.getLastIndex(lines);
      Iterable $this$mapIndexedNotNull$iv$iv = (Iterable)lines;
      int $i$f$mapIndexedNotNull = false;
      Collection destination$iv$iv$iv = (Collection)(new ArrayList());
      $i$f$mapIndexedNotNullTo = false;
      int $i$f$forEachIndexed = false;
      int index$iv$iv$iv$iv = 0;
      Iterator var17 = $this$mapIndexedNotNull$iv$iv.iterator();

      String var40;
      while(var17.hasNext()) {
         Object item$iv$iv$iv$iv = var17.next();
         int var19 = index$iv$iv$iv$iv++;
         if (var19 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         int var22 = false;
         String value$iv = (String)item$iv$iv$iv$iv;
         int var25 = false;
         if ((var19 == 0 || var19 == lastIndex$iv) && StringsKt.isBlank((CharSequence)value$iv)) {
            var40 = null;
         } else {
            label76: {
               int var27 = false;
               var40 = StringsKt.drop(value$iv, minCommonIndent);
               if (var40 != null) {
                  String var28 = var40;
                  var40 = (String)indentAddFunction$iv.invoke(var28);
                  if (var40 != null) {
                     break label76;
                  }
               }

               var40 = value$iv;
            }
         }

         if (var40 != null) {
            String var29 = var40;
            int var31 = false;
            destination$iv$iv$iv.add(var29);
         }
      }

      var40 = ((StringBuilder)CollectionsKt.joinTo$default((Iterable)((List)destination$iv$iv$iv), (Appendable)(new StringBuilder(resultSizeEstimate$iv)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 124, (Object)null)).toString();
      Intrinsics.checkNotNullExpressionValue(var40, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
      return var40;
   }

   // $FF: synthetic method
   public static String replaceIndent$default(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "";
      }

      return StringsKt.replaceIndent(var0, var1);
   }

   @NotNull
   public static final String prependIndent(@NotNull String $this$prependIndent, @NotNull final String indent) {
      Intrinsics.checkNotNullParameter($this$prependIndent, "<this>");
      Intrinsics.checkNotNullParameter(indent, "indent");
      return SequencesKt.joinToString$default(SequencesKt.map(StringsKt.lineSequence((CharSequence)$this$prependIndent), (Function1)(new Function1() {
         @NotNull
         public final String invoke(@NotNull String it) {
            Intrinsics.checkNotNullParameter(it, "it");
            return StringsKt.isBlank((CharSequence)it) ? (it.length() < indent.length() ? indent : it) : indent + it;
         }
      })), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
   }

   // $FF: synthetic method
   public static String prependIndent$default(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "    ";
      }

      return StringsKt.prependIndent(var0, var1);
   }

   private static final int indentWidth$StringsKt__IndentKt(String $this$indentWidth) {
      CharSequence $this$indexOfFirst$iv = (CharSequence)$this$indentWidth;
      int $i$f$indexOfFirst = false;
      int index$iv = 0;
      int var4 = $this$indexOfFirst$iv.length();

      int var10000;
      while(true) {
         if (index$iv >= var4) {
            var10000 = -1;
            break;
         }

         char it = $this$indexOfFirst$iv.charAt(index$iv);
         int var6 = false;
         if (!CharsKt.isWhitespace(it)) {
            var10000 = index$iv;
            break;
         }

         ++index$iv;
      }

      int var7 = var10000;
      int var8 = false;
      return var7 == -1 ? $this$indentWidth.length() : var7;
   }

   private static final Function1 getIndentFunction$StringsKt__IndentKt(final String indent) {
      return ((CharSequence)indent).length() == 0 ? (Function1)null.INSTANCE : (Function1)(new Function1() {
         @NotNull
         public final String invoke(@NotNull String line) {
            Intrinsics.checkNotNullParameter(line, "line");
            return indent + line;
         }
      });
   }

   private static final String reindent$StringsKt__IndentKt(List $this$reindent, int resultSizeEstimate, Function1 indentAddFunction, Function1 indentCutFunction) {
      int $i$f$reindent = false;
      int lastIndex = CollectionsKt.getLastIndex($this$reindent);
      Iterable $this$mapIndexedNotNull$iv = (Iterable)$this$reindent;
      int $i$f$mapIndexedNotNull = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$mapIndexedNotNullTo = false;
      int $i$f$forEachIndexed = false;
      int index$iv$iv$iv = 0;
      Iterator var14 = $this$mapIndexedNotNull$iv.iterator();

      String var27;
      while(var14.hasNext()) {
         Object item$iv$iv$iv = var14.next();
         int var16 = index$iv$iv$iv++;
         if (var16 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         int var19 = false;
         String value = (String)item$iv$iv$iv;
         int var22 = false;
         if ((var16 == 0 || var16 == lastIndex) && StringsKt.isBlank((CharSequence)value)) {
            var27 = null;
         } else {
            label40: {
               var27 = (String)indentCutFunction.invoke(value);
               if (var27 != null) {
                  String var23 = var27;
                  var27 = (String)indentAddFunction.invoke(var23);
                  if (var27 != null) {
                     break label40;
                  }
               }

               var27 = value;
            }
         }

         if (var27 != null) {
            String var24 = var27;
            int var26 = false;
            destination$iv$iv.add(var24);
         }
      }

      var27 = ((StringBuilder)CollectionsKt.joinTo$default((Iterable)((List)destination$iv$iv), (Appendable)(new StringBuilder(resultSizeEstimate)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 124, (Object)null)).toString();
      Intrinsics.checkNotNullExpressionValue(var27, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
      return var27;
   }

   public StringsKt__IndentKt() {
   }
}
