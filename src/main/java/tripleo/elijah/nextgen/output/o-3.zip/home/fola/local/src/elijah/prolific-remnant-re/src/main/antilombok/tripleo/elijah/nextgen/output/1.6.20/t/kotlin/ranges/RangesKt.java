package kotlin.ranges;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/ranges/RangesKt__RangesKt", "kotlin/ranges/RangesKt___RangesKt"}
)
public final class RangesKt extends RangesKt___RangesKt {
   private RangesKt() {
   }
}
