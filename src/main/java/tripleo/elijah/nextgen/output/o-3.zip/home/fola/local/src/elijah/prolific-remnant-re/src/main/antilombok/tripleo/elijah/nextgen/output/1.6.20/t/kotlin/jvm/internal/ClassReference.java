package kotlin.jvm.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.SinceKotlin;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.KotlinReflectionNotSupportedError;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function10;
import kotlin.jvm.functions.Function11;
import kotlin.jvm.functions.Function12;
import kotlin.jvm.functions.Function13;
import kotlin.jvm.functions.Function14;
import kotlin.jvm.functions.Function15;
import kotlin.jvm.functions.Function16;
import kotlin.jvm.functions.Function17;
import kotlin.jvm.functions.Function18;
import kotlin.jvm.functions.Function19;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function20;
import kotlin.jvm.functions.Function21;
import kotlin.jvm.functions.Function22;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.functions.Function6;
import kotlin.jvm.functions.Function7;
import kotlin.jvm.functions.Function8;
import kotlin.jvm.functions.Function9;
import kotlin.reflect.KClass;
import kotlin.reflect.KVisibility;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u001b\n\u0002\b\u0003\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0016\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\u0018\u0000 O2\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003:\u0001OB\u0011\u0012\n\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005¢\u0006\u0002\u0010\u0006J\u0013\u0010F\u001a\u00020\u00122\b\u0010G\u001a\u0004\u0018\u00010\u0002H\u0096\u0002J\b\u0010H\u001a\u00020IH\u0002J\b\u0010J\u001a\u00020KH\u0016J\u0012\u0010L\u001a\u00020\u00122\b\u0010M\u001a\u0004\u0018\u00010\u0002H\u0017J\b\u0010N\u001a\u000201H\u0016R\u001a\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR \u0010\f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u000e0\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u001a\u0010\u0011\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0011\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u0017\u0010\u0014\u001a\u0004\b\u0016\u0010\u0015R\u001a\u0010\u0018\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u0019\u0010\u0014\u001a\u0004\b\u0018\u0010\u0015R\u001a\u0010\u001a\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u001b\u0010\u0014\u001a\u0004\b\u001a\u0010\u0015R\u001a\u0010\u001c\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u001d\u0010\u0014\u001a\u0004\b\u001c\u0010\u0015R\u001a\u0010\u001e\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b\u001f\u0010\u0014\u001a\u0004\b\u001e\u0010\u0015R\u001a\u0010 \u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b!\u0010\u0014\u001a\u0004\b \u0010\u0015R\u001a\u0010\"\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b#\u0010\u0014\u001a\u0004\b\"\u0010\u0015R\u001a\u0010$\u001a\u00020\u00128VX\u0097\u0004¢\u0006\f\u0012\u0004\b%\u0010\u0014\u001a\u0004\b$\u0010\u0015R\u0018\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b&\u0010'R\u001e\u0010(\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030)0\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b*\u0010\u0010R\u001e\u0010+\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00010\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b,\u0010\u0010R\u0016\u0010-\u001a\u0004\u0018\u00010\u00028VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b.\u0010/R\u0016\u00100\u001a\u0004\u0018\u0001018VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b2\u00103R(\u00104\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00020\u00010\b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b5\u0010\u0014\u001a\u0004\b6\u0010\u000bR\u0016\u00107\u001a\u0004\u0018\u0001018VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b8\u00103R \u00109\u001a\b\u0012\u0004\u0012\u00020:0\b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b;\u0010\u0014\u001a\u0004\b<\u0010\u000bR \u0010=\u001a\b\u0012\u0004\u0012\u00020>0\b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b?\u0010\u0014\u001a\u0004\b@\u0010\u000bR\u001c\u0010A\u001a\u0004\u0018\u00010B8VX\u0097\u0004¢\u0006\f\u0012\u0004\bC\u0010\u0014\u001a\u0004\bD\u0010E¨\u0006P"},
   d2 = {"Lkotlin/jvm/internal/ClassReference;", "Lkotlin/reflect/KClass;", "", "Lkotlin/jvm/internal/ClassBasedDeclarationContainer;", "jClass", "Ljava/lang/Class;", "(Ljava/lang/Class;)V", "annotations", "", "", "getAnnotations", "()Ljava/util/List;", "constructors", "", "Lkotlin/reflect/KFunction;", "getConstructors", "()Ljava/util/Collection;", "isAbstract", "", "isAbstract$annotations", "()V", "()Z", "isCompanion", "isCompanion$annotations", "isData", "isData$annotations", "isFinal", "isFinal$annotations", "isFun", "isFun$annotations", "isInner", "isInner$annotations", "isOpen", "isOpen$annotations", "isSealed", "isSealed$annotations", "isValue", "isValue$annotations", "getJClass", "()Ljava/lang/Class;", "members", "Lkotlin/reflect/KCallable;", "getMembers", "nestedClasses", "getNestedClasses", "objectInstance", "getObjectInstance", "()Ljava/lang/Object;", "qualifiedName", "", "getQualifiedName", "()Ljava/lang/String;", "sealedSubclasses", "getSealedSubclasses$annotations", "getSealedSubclasses", "simpleName", "getSimpleName", "supertypes", "Lkotlin/reflect/KType;", "getSupertypes$annotations", "getSupertypes", "typeParameters", "Lkotlin/reflect/KTypeParameter;", "getTypeParameters$annotations", "getTypeParameters", "visibility", "Lkotlin/reflect/KVisibility;", "getVisibility$annotations", "getVisibility", "()Lkotlin/reflect/KVisibility;", "equals", "other", "error", "", "hashCode", "", "isInstance", "value", "toString", "Companion", "kotlin-stdlib"}
)
public final class ClassReference implements KClass, ClassBasedDeclarationContainer {
   @NotNull
   public static final ClassReference.Companion Companion = new ClassReference.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Class jClass;
   @NotNull
   private static final Map FUNCTION_CLASSES;
   @NotNull
   private static final HashMap primitiveFqNames;
   @NotNull
   private static final HashMap primitiveWrapperFqNames;
   @NotNull
   private static final HashMap classFqNames;
   @NotNull
   private static final Map simpleNames;

   public ClassReference(@NotNull Class jClass) {
      Intrinsics.checkNotNullParameter(jClass, "jClass");
      super();
      this.jClass = jClass;
   }

   @NotNull
   public Class getJClass() {
      return this.jClass;
   }

   @Nullable
   public String getSimpleName() {
      return Companion.getClassSimpleName(this.getJClass());
   }

   @Nullable
   public String getQualifiedName() {
      return Companion.getClassQualifiedName(this.getJClass());
   }

   @NotNull
   public Collection getMembers() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Collection getConstructors() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Collection getNestedClasses() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public List getAnnotations() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @Nullable
   public Object getObjectInstance() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @SinceKotlin(
      version = "1.1"
   )
   public boolean isInstance(@Nullable Object value) {
      return Companion.isInstance(value, this.getJClass());
   }

   @NotNull
   public List getTypeParameters() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getTypeParameters$annotations() {
   }

   @NotNull
   public List getSupertypes() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getSupertypes$annotations() {
   }

   @NotNull
   public List getSealedSubclasses() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.3"
   )
   public static void getSealedSubclasses$annotations() {
   }

   @Nullable
   public KVisibility getVisibility() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getVisibility$annotations() {
   }

   public boolean isFinal() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isFinal$annotations() {
   }

   public boolean isOpen() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isOpen$annotations() {
   }

   public boolean isAbstract() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isAbstract$annotations() {
   }

   public boolean isSealed() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isSealed$annotations() {
   }

   public boolean isData() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isData$annotations() {
   }

   public boolean isInner() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isInner$annotations() {
   }

   public boolean isCompanion() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isCompanion$annotations() {
   }

   public boolean isFun() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.4"
   )
   public static void isFun$annotations() {
   }

   public boolean isValue() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.5"
   )
   public static void isValue$annotations() {
   }

   private final Void error() {
      throw new KotlinReflectionNotSupportedError();
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof ClassReference && Intrinsics.areEqual((Object)JvmClassMappingKt.getJavaObjectType((KClass)this), (Object)JvmClassMappingKt.getJavaObjectType((KClass)other));
   }

   public int hashCode() {
      return JvmClassMappingKt.getJavaObjectType((KClass)this).hashCode();
   }

   @NotNull
   public String toString() {
      return this.getJClass().toString() + " (Kotlin reflection is not available)";
   }

   static {
      Class[] var0 = new Class[]{Function0.class, Function1.class, Function2.class, Function3.class, Function4.class, Function5.class, Function6.class, Function7.class, Function8.class, Function9.class, Function10.class, Function11.class, Function12.class, Function13.class, Function14.class, Function15.class, Function16.class, Function17.class, Function18.class, Function19.class, Function20.class, Function21.class, Function22.class};
      Iterable $this$mapIndexed$iv = (Iterable)CollectionsKt.listOf(var0);
      int $i$f$mapValues = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$mapIndexed$iv, 10)));
      int $i$f$mapValuesTo = false;
      int index$iv$iv = 0;
      Iterator var6 = $this$mapIndexed$iv.iterator();

      boolean var11;
      while(var6.hasNext()) {
         Object item$iv$iv = var6.next();
         int var8 = index$iv$iv++;
         if (var8 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         Class clazz = (Class)item$iv$iv;
         var11 = false;
         destination$iv$iv.add(TuplesKt.to(clazz, var8));
      }

      FUNCTION_CLASSES = MapsKt.toMap((Iterable)((List)destination$iv$iv));
      HashMap var19 = new HashMap();
      int var2 = false;
      var19.put("boolean", "kotlin.Boolean");
      var19.put("char", "kotlin.Char");
      var19.put("byte", "kotlin.Byte");
      var19.put("short", "kotlin.Short");
      var19.put("int", "kotlin.Int");
      var19.put("float", "kotlin.Float");
      var19.put("long", "kotlin.Long");
      var19.put("double", "kotlin.Double");
      primitiveFqNames = var19;
      var19 = new HashMap();
      var2 = false;
      var19.put("java.lang.Boolean", "kotlin.Boolean");
      var19.put("java.lang.Character", "kotlin.Char");
      var19.put("java.lang.Byte", "kotlin.Byte");
      var19.put("java.lang.Short", "kotlin.Short");
      var19.put("java.lang.Integer", "kotlin.Int");
      var19.put("java.lang.Float", "kotlin.Float");
      var19.put("java.lang.Long", "kotlin.Long");
      var19.put("java.lang.Double", "kotlin.Double");
      primitiveWrapperFqNames = var19;
      var19 = new HashMap();
      HashMap $this$classFqNames_u24lambda_u2d4 = var19;
      var2 = false;
      var19.put("java.lang.Object", "kotlin.Any");
      var19.put("java.lang.String", "kotlin.String");
      var19.put("java.lang.CharSequence", "kotlin.CharSequence");
      var19.put("java.lang.Throwable", "kotlin.Throwable");
      var19.put("java.lang.Cloneable", "kotlin.Cloneable");
      var19.put("java.lang.Number", "kotlin.Number");
      var19.put("java.lang.Comparable", "kotlin.Comparable");
      var19.put("java.lang.Enum", "kotlin.Enum");
      var19.put("java.lang.annotation.Annotation", "kotlin.Annotation");
      var19.put("java.lang.Iterable", "kotlin.collections.Iterable");
      var19.put("java.util.Iterator", "kotlin.collections.Iterator");
      var19.put("java.util.Collection", "kotlin.collections.Collection");
      var19.put("java.util.List", "kotlin.collections.List");
      var19.put("java.util.Set", "kotlin.collections.Set");
      var19.put("java.util.ListIterator", "kotlin.collections.ListIterator");
      var19.put("java.util.Map", "kotlin.collections.Map");
      var19.put("java.util.Map$Entry", "kotlin.collections.Map.Entry");
      var19.put("kotlin.jvm.internal.StringCompanionObject", "kotlin.String.Companion");
      var19.put("kotlin.jvm.internal.EnumCompanionObject", "kotlin.Enum.Companion");
      var19.putAll((Map)primitiveFqNames);
      var19.putAll((Map)primitiveWrapperFqNames);
      Collection var10000 = primitiveFqNames.values();
      Intrinsics.checkNotNullExpressionValue(var10000, "primitiveFqNames.values");
      Iterable $this$associateTo$iv = (Iterable)var10000;
      $i$f$mapValuesTo = false;
      Iterator var26 = $this$associateTo$iv.iterator();

      while(var26.hasNext()) {
         Object element$iv = var26.next();
         Map var32 = (Map)$this$classFqNames_u24lambda_u2d4;
         String kotlinName = (String)element$iv;
         int var37 = false;
         StringBuilder var39 = (new StringBuilder()).append("kotlin.jvm.internal.");
         Intrinsics.checkNotNullExpressionValue(kotlinName, "kotlinName");
         Pair var35 = TuplesKt.to(var39.append(StringsKt.substringAfterLast$default(kotlinName, '.', (String)null, 2, (Object)null)).append("CompanionObject").toString(), kotlinName + ".Companion");
         var32.put(var35.getFirst(), var35.getSecond());
      }

      Map var40 = (Map)$this$classFqNames_u24lambda_u2d4;
      Iterator var23 = FUNCTION_CLASSES.entrySet().iterator();

      while(var23.hasNext()) {
         Entry var25 = (Entry)var23.next();
         Class klass = (Class)var25.getKey();
         int arity = ((Number)var25.getValue()).intValue();
         $this$classFqNames_u24lambda_u2d4.put(klass.getName(), "kotlin.Function" + arity);
      }

      classFqNames = var19;
      Map $this$mapValues$iv = (Map)classFqNames;
      $i$f$mapValues = false;
      Map destination$iv$iv = (Map)(new LinkedHashMap(MapsKt.mapCapacity($this$mapValues$iv.size())));
      $i$f$mapValuesTo = false;
      Iterable $this$associateByTo$iv$iv$iv = (Iterable)$this$mapValues$iv.entrySet();
      int $i$f$associateByTo = false;
      Iterator var33 = $this$associateByTo$iv$iv$iv.iterator();

      while(var33.hasNext()) {
         Object element$iv$iv$iv = var33.next();
         Entry it$iv$iv = (Entry)element$iv$iv$iv;
         var11 = false;
         Object var41 = it$iv$iv.getKey();
         Entry var12 = (Entry)element$iv$iv$iv;
         Object var16 = var41;
         int var13 = false;
         String fqName = (String)var12.getValue();
         String var17 = StringsKt.substringAfterLast$default(fqName, '.', (String)null, 2, (Object)null);
         destination$iv$iv.put(var16, var17);
      }

      simpleNames = destination$iv$iv;
   }

   @Metadata(
      mv = {1, 6, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0014\u0010\u000f\u001a\u0004\u0018\u00010\n2\n\u0010\u0010\u001a\u0006\u0012\u0002\b\u00030\u0005J\u0014\u0010\u0011\u001a\u0004\u0018\u00010\n2\n\u0010\u0010\u001a\u0006\u0012\u0002\b\u00030\u0005J\u001c\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u00012\n\u0010\u0010\u001a\u0006\u0012\u0002\b\u00030\u0005R&\u0010\u0003\u001a\u001a\u0012\u0010\u0012\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005\u0012\u0004\u0012\u00020\u00070\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\b\u001a\u001e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\tj\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n`\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\f\u001a\u001e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\tj\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n`\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\r\u001a\u001e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\tj\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n`\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"},
      d2 = {"Lkotlin/jvm/internal/ClassReference$Companion;", "", "()V", "FUNCTION_CLASSES", "", "Ljava/lang/Class;", "Lkotlin/Function;", "", "classFqNames", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "primitiveFqNames", "primitiveWrapperFqNames", "simpleNames", "getClassQualifiedName", "jClass", "getClassSimpleName", "isInstance", "", "value", "kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      @Nullable
      public final String getClassSimpleName(@NotNull Class jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         String var10000;
         if (jClass.isAnonymousClass()) {
            var10000 = null;
         } else if (jClass.isLocalClass()) {
            String name = jClass.getSimpleName();
            Method var9 = jClass.getEnclosingMethod();
            if (var9 != null) {
               Method var4 = var9;
               int var6 = false;
               Intrinsics.checkNotNullExpressionValue(name, "name");
               var10000 = StringsKt.substringAfter$default(name, var4.getName() + '$', (String)null, 2, (Object)null);
               if (var10000 != null) {
                  return var10000;
               }
            }

            Constructor var10 = jClass.getEnclosingConstructor();
            if (var10 != null) {
               Constructor var5 = var10;
               int var7 = false;
               Intrinsics.checkNotNullExpressionValue(name, "name");
               var10000 = StringsKt.substringAfter$default(name, var5.getName() + '$', (String)null, 2, (Object)null);
            } else {
               Intrinsics.checkNotNullExpressionValue(name, "name");
               var10000 = StringsKt.substringAfter$default(name, '$', (String)null, 2, (Object)null);
            }
         } else if (jClass.isArray()) {
            Class componentType = jClass.getComponentType();
            if (componentType.isPrimitive()) {
               String var3 = (String)ClassReference.simpleNames.get(componentType.getName());
               var10000 = var3 != null ? var3 + "Array" : null;
            } else {
               var10000 = null;
            }

            if (var10000 == null) {
               var10000 = "Array";
            }
         } else {
            var10000 = (String)ClassReference.simpleNames.get(jClass.getName());
            if (var10000 == null) {
               var10000 = jClass.getSimpleName();
            }
         }

         return var10000;
      }

      @Nullable
      public final String getClassQualifiedName(@NotNull Class jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         String var10000;
         if (jClass.isAnonymousClass()) {
            var10000 = null;
         } else if (jClass.isLocalClass()) {
            var10000 = null;
         } else if (jClass.isArray()) {
            Class componentType = jClass.getComponentType();
            if (componentType.isPrimitive()) {
               String var3 = (String)ClassReference.classFqNames.get(componentType.getName());
               var10000 = var3 != null ? var3 + "Array" : null;
            } else {
               var10000 = null;
            }

            if (var10000 == null) {
               var10000 = "kotlin.Array";
            }
         } else {
            var10000 = (String)ClassReference.classFqNames.get(jClass.getName());
            if (var10000 == null) {
               var10000 = jClass.getCanonicalName();
            }
         }

         return var10000;
      }

      public final boolean isInstance(@Nullable Object value, @NotNull Class jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         Integer var3 = (Integer)ClassReference.FUNCTION_CLASSES.get(jClass);
         if (var3 != null) {
            int arity = ((Number)var3).intValue();
            int var6 = false;
            return TypeIntrinsics.isFunctionOfArity(value, arity);
         } else {
            Class objectType = jClass.isPrimitive() ? JvmClassMappingKt.getJavaObjectType(JvmClassMappingKt.getKotlinClass(jClass)) : jClass;
            return objectType.isInstance(value);
         }
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
