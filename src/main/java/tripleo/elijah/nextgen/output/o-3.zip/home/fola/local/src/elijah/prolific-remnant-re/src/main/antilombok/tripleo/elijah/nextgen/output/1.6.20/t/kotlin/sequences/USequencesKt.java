package kotlin.sequences;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/sequences/USequencesKt___USequencesKt"}
)
public final class USequencesKt extends USequencesKt___USequencesKt {
   private USequencesKt() {
   }
}
