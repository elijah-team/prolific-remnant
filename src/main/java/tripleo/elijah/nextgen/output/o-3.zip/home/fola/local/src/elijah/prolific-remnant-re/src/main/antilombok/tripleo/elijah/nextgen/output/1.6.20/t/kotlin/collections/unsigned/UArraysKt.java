package kotlin.collections.unsigned;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/collections/unsigned/UArraysKt___UArraysJvmKt", "kotlin/collections/unsigned/UArraysKt___UArraysKt"},
   pn = "kotlin.collections"
)
public final class UArraysKt extends UArraysKt___UArraysKt {
   private UArraysKt() {
   }
}
