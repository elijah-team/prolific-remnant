package kotlin.collections;

import kotlin.Metadata;

@Metadata(
   mv = {1, 6, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/collections/MapsKt__MapWithDefaultKt", "kotlin/collections/MapsKt__MapsJVMKt", "kotlin/collections/MapsKt__MapsKt", "kotlin/collections/MapsKt___MapsKt"}
)
public final class MapsKt extends MapsKt___MapsKt {
   private MapsKt() {
   }
}
