package kotlin.sequences;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 6, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010(\n\u0000\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u0002*\u0004\b\u0002\u0010\u00032\b\u0012\u0004\u0012\u0002H\u00030\u0004B;\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004\u0012\u0018\u0010\u0007\u001a\u0014\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00028\u00020\b¢\u0006\u0002\u0010\tJ\u000f\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00020\u000bH\u0096\u0002R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u0007\u001a\u0014\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00028\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\f"},
   d2 = {"Lkotlin/sequences/MergingSequence;", "T1", "T2", "V", "Lkotlin/sequences/Sequence;", "sequence1", "sequence2", "transform", "Lkotlin/Function2;", "(Lkotlin/sequences/Sequence;Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function2;)V", "iterator", "", "kotlin-stdlib"}
)
public final class MergingSequence implements Sequence {
   @NotNull
   private final Sequence sequence1;
   @NotNull
   private final Sequence sequence2;
   @NotNull
   private final Function2 transform;

   public MergingSequence(@NotNull Sequence sequence1, @NotNull Sequence sequence2, @NotNull Function2 transform) {
      Intrinsics.checkNotNullParameter(sequence1, "sequence1");
      Intrinsics.checkNotNullParameter(sequence2, "sequence2");
      Intrinsics.checkNotNullParameter(transform, "transform");
      super();
      this.sequence1 = sequence1;
      this.sequence2 = sequence2;
      this.transform = transform;
   }

   @NotNull
   public Iterator iterator() {
      return (Iterator)(new Iterator() {
         @NotNull
         private final Iterator iterator1;
         @NotNull
         private final Iterator iterator2;

         {
            this.iterator1 = MergingSequence.this.sequence1.iterator();
            this.iterator2 = MergingSequence.this.sequence2.iterator();
         }

         @NotNull
         public final Iterator getIterator1() {
            return this.iterator1;
         }

         @NotNull
         public final Iterator getIterator2() {
            return this.iterator2;
         }

         public Object next() {
            return MergingSequence.this.transform.invoke(this.iterator1.next(), this.iterator2.next());
         }

         public boolean hasNext() {
            return this.iterator1.hasNext() && this.iterator2.hasNext();
         }

         public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
         }
      });
   }
}
