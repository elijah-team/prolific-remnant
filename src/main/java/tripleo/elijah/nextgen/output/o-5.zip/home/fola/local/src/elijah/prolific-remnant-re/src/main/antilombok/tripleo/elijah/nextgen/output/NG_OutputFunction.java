package tripleo.elijah.nextgen.output;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.jvm.functions.Function0;
import org.jetbrains.annotations.NotNull;
import tripleo.elijah.nextgen.outputstatement.EG_Statement;
import tripleo.elijah.nextgen.outputtree.EOT_FileNameProvider;
import tripleo.elijah.stages.gen_c.C2C_Result;
import tripleo.elijah.stages.gen_fn.BaseEvaFunction;
import tripleo.elijah.stages.gen_fn.EvaConstructor;
import tripleo.elijah.stages.gen_fn.EvaFunction;
import tripleo.elijah.stages.gen_generic.GenerateFiles;
import tripleo.elijah.stages.gen_generic.GenerateResult.TY;
import tripleo.elijah.stages.generate.OutputStrategyC;

public class NG_OutputFunction implements NG_OutputItem {
   private List collect;
   private GenerateFiles generateFiles;
   private BaseEvaFunction gf;

   @NotNull
   public List getOutputs() {
      List r = new ArrayList();
      if (this.collect != null) {
         Iterator var2 = this.collect.iterator();

         while(var2.hasNext()) {
            C2C_Result c2c = (C2C_Result)var2.next();
            EG_Statement x = c2c.getStatement();
            TY y = c2c.ty();
            r.add(new NG_OutputFunctionStatement(c2c));
         }
      }

      Lazy filename_$delegate = LazyKt.lazy(new Function0() {
         public final String invoke() {
            return "";
         }
      });
      if (r == null) {
         $$$reportNull$$$0(0);
      }

      return r;
   }

   public EOT_FileNameProvider outName(@NotNull OutputStrategyC aOutputStrategyC, @NotNull TY ty) {
      if (aOutputStrategyC == null) {
         $$$reportNull$$$0(1);
      }

      if (ty == null) {
         $$$reportNull$$$0(2);
      }

      return (EOT_FileNameProvider)(this.gf instanceof EvaFunction ? aOutputStrategyC.nameForFunction1((EvaFunction)this.gf, ty) : aOutputStrategyC.nameForConstructor1((EvaConstructor)this.gf, ty));
   }

   public void setFunction(BaseEvaFunction aGf, GenerateFiles aGenerateFiles, List aCollect) {
      this.gf = aGf;
      this.generateFiles = aGenerateFiles;
      this.collect = aCollect;
   }

   // $FF: synthetic method
   private static void $$$reportNull$$$0(int var0) {
      String var10000;
      switch(var0) {
      case 0:
      default:
         var10000 = "@NotNull method %s.%s must not return null";
         break;
      case 1:
      case 2:
         var10000 = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
      }

      byte var10001;
      switch(var0) {
      case 0:
      default:
         var10001 = 2;
         break;
      case 1:
      case 2:
         var10001 = 3;
      }

      Object[] var2 = new Object[var10001];
      switch(var0) {
      case 0:
      default:
         var2[0] = "tripleo/elijah/nextgen/output/NG_OutputFunction";
         break;
      case 1:
         var2[0] = "aOutputStrategyC";
         break;
      case 2:
         var2[0] = "ty";
      }

      switch(var0) {
      case 0:
      default:
         var2[1] = "getOutputs";
         break;
      case 1:
      case 2:
         var2[1] = "tripleo/elijah/nextgen/output/NG_OutputFunction";
      }

      switch(var0) {
      case 1:
      case 2:
         var2[2] = "outName";
      case 0:
      default:
         var10000 = String.format(var10000, var2);
         Object var1;
         String var4;
         switch(var0) {
         case 0:
         default:
            IllegalStateException var3 = new IllegalStateException;
            var4 = var10000;
            var1 = var3;
            var3.<init>(var4);
            break;
         case 1:
         case 2:
            IllegalArgumentException var10002 = new IllegalArgumentException;
            var4 = var10000;
            var1 = var10002;
            var10002.<init>(var4);
         }

         throw var1;
      }
   }
}
