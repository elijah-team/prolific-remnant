package tripleo.elijah.nextgen.output;

import java.util.List;
import org.jetbrains.annotations.NotNull;
import tripleo.elijah.nextgen.outputtree.EOT_FileNameProvider;
import tripleo.elijah.stages.garish.GarishClass;
import tripleo.elijah.stages.gen_c.GenerateC;
import tripleo.elijah.stages.gen_fn.EvaClass;
import tripleo.elijah.stages.gen_generic.GenerateResult.TY;
import tripleo.elijah.stages.generate.OutputStrategyC;
import tripleo.elijah.util.BufferTabbedOutputStream;
import tripleo.elijah.util.Helpers;

public class NG_OutputClass implements NG_OutputItem {
   private GarishClass garishClass;
   private GenerateC generateC;

   @NotNull
   public List getOutputs() {
      EvaClass x = this.garishClass.getLiving().evaNode();
      BufferTabbedOutputStream tos = this.garishClass.getClassBuffer(this.generateC);
      NG_OutputClassStatement implText = new NG_OutputClassStatement(tos, x.module(), TY.IMPL);
      BufferTabbedOutputStream tosHdr = this.garishClass.getHeaderBuffer(this.generateC);
      NG_OutputClassStatement headerText = new NG_OutputClassStatement(tosHdr, x.module(), TY.HEADER);
      List var10000 = Helpers.List_of(new NG_OutputStatement[]{implText, headerText});
      if (var10000 == null) {
         $$$reportNull$$$0(0);
      }

      return var10000;
   }

   public EOT_FileNameProvider outName(@NotNull OutputStrategyC aOutputStrategyC, @NotNull TY ty) {
      if (aOutputStrategyC == null) {
         $$$reportNull$$$0(1);
      }

      if (ty == null) {
         $$$reportNull$$$0(2);
      }

      EvaClass x = this.garishClass.getLiving().evaNode();
      return aOutputStrategyC.nameForClass1(x, ty);
   }

   public void setClass(GarishClass aGarishClass, GenerateC aGenerateC) {
      this.garishClass = aGarishClass;
      this.generateC = aGenerateC;
   }

   // $FF: synthetic method
   private static void $$$reportNull$$$0(int var0) {
      String var10000;
      switch(var0) {
      case 0:
      default:
         var10000 = "@NotNull method %s.%s must not return null";
         break;
      case 1:
      case 2:
         var10000 = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
      }

      byte var10001;
      switch(var0) {
      case 0:
      default:
         var10001 = 2;
         break;
      case 1:
      case 2:
         var10001 = 3;
      }

      Object[] var2 = new Object[var10001];
      switch(var0) {
      case 0:
      default:
         var2[0] = "tripleo/elijah/nextgen/output/NG_OutputClass";
         break;
      case 1:
         var2[0] = "aOutputStrategyC";
         break;
      case 2:
         var2[0] = "ty";
      }

      switch(var0) {
      case 0:
      default:
         var2[1] = "getOutputs";
         break;
      case 1:
      case 2:
         var2[1] = "tripleo/elijah/nextgen/output/NG_OutputClass";
      }

      switch(var0) {
      case 1:
      case 2:
         var2[2] = "outName";
      case 0:
      default:
         var10000 = String.format(var10000, var2);
         Object var1;
         String var4;
         switch(var0) {
         case 0:
         default:
            IllegalStateException var3 = new IllegalStateException;
            var4 = var10000;
            var1 = var3;
            var3.<init>(var4);
            break;
         case 1:
         case 2:
            IllegalArgumentException var10002 = new IllegalArgumentException;
            var4 = var10000;
            var1 = var10002;
            var10002.<init>(var4);
         }

         throw var1;
      }
   }
}
