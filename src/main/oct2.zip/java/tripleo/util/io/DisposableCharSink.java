package tripleo.util.io;

import tripleo.util.Disposable;

public interface DisposableCharSink extends Disposable, CharSink, AutoCloseable {
}
