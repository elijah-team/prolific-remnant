package tripleo.util;

public interface Disposable {
	void dispose();
}
