package tripleo.elijah.nextgen.query;

public class QueryDatabase {
}
