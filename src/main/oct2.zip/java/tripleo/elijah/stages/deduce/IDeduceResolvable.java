package tripleo.elijah.stages.deduce;

public interface IDeduceResolvable {
}
