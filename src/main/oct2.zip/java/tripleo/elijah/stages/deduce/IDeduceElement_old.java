package tripleo.elijah.stages.deduce;

public interface IDeduceElement_old {
}
