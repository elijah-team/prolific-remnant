package tripleo.elijah.lang;

/*
 * Created on 5/19/2019 at 23:36
 *
 * $$Id$
 *
 */
public class InvariantStatement {
}
