/**
 * 
 */
package tripleo.elijah.lang;

/**
 * @author Tripleo
 *
 * Created 	Mar 27, 2020 at 1:13:13 AM
 */
public enum NamespaceModify {
	IMPORT
}

//
//
//
